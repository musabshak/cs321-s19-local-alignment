References

mouse Titin: https://www.ncbi.nlm.nih.gov/protein/A2ASS6.1
human Titin: https://www.ncbi.nlm.nih.gov/protein/CAD12456.1
dog Titin: https://www.uniprot.org/uniprot/F1PV45.txt
vtml20: https://github.com/soedinglab/MMseqs2/blob/master/data/VTML20.out
deciding indel penalty: https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3848038/

* humanmouse1.txt contains the cleaned Titin proteins. The first line is the human Titin 
and the second line is the mouse Titin.
* results1.txt contains the aligned sequences 
* timenscore1.txt contains the optimal alignment score and the time it took for the program to complete
* vtml20.txt contains the vtml20 score matrix 